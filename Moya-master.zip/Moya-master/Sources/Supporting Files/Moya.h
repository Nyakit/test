//
//  Moya.h
//  Moya
//

#import <Foundation/Foundation.h>

//! Project version number for Moya.
FOUNDATION_EXPORT double MoyaVersionNumber;

//! Project version string for Moya.
FOUNDATION_EXPORT const unsigned char MoyaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Moya/PublicHeader.h>
