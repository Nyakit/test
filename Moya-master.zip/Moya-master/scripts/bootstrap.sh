#!/bin/sh

carthage bootstrap
cp Cartfile.resolved Carthage
